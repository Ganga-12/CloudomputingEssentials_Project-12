#!/bin/bash
touch Log_Day_{1..100}
